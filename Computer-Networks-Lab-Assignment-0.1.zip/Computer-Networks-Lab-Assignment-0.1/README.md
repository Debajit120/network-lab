# Computer-Networks-Lab-Assignment

Team Name: Error404

Run FServer as 
<br><br>
`java FServer <port-number>`
<br><br>
Run FClient as 
<br><br>
`java FClient ipaddress <port-number>`
